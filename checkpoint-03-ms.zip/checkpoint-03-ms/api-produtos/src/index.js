const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

mongoose
  .connect(
    "mongodb+srv://bryan:bryan@cluster-checkpoint-ms.dgpd37w.mongodb.net/checkpoint_ms?retryWrites=true&w=majority"
  )
  .then(() => {
    console.log("Conectado com o banco de dados!");
  })
  .catch((error) => {
    console.log(error);
  });

const route = require("./routes/productRoute");
app.use("/produto", route);

app.listen(3000, () => console.log(`Rodando na porta 3000...`));
