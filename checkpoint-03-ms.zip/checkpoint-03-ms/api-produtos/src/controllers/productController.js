const Product = require("../mongoose/model/Product");
const { default: axios } = require("axios");

exports.get = (req, res, next) => {
  Product.find({})
    .exec()
    .then((products) => res.status(200).json(products))
    .catch((error) => res.status(400).send(error));
};

exports.post = async (req, res, next) => {
  console.log(req.body);
  Product.create(req.body)
    .then((product) => {
      res.status(200).json(product);

      const mailBody = {
        emailFrom: "bryanroncon@gmail.com",
        emailTo: "bryanroncon@outlook.com",
        subject: `Nova inserção de produto - ${req.body.name}`,
        text:
          `Nome: ${req.body.name}\n` +
          `Preço: R$ ${req.body.price}\n` +
          `Quantidade: ${req.body.quantity}`,
      };
      axios
        .post("http://localhost:8080/send-email", mailBody)
        .catch((error) => console.log(error));
    })
    .catch((error) => res.status(400).send(error));
};
