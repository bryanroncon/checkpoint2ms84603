const getProducts = () =>
  new Promise((resolve, reject) => {
    fetch("http://localhost:3000/produto")
      .then((response) => {
        response.json().then((products) => {
          resolve(products);
        });
      })
      .catch((error) => {
        console.log(error);
        reject(error);
      });
  });

const init = async () => {
  getProducts().then((products) => {
    const tbody = document.querySelector(".product-table tbody");

    const htmlList = products.reduce((acc, product, index) => {
      const li = `
        <tr>
          <td>${index + 1}</td>
          <td>${product.name}</td>
          <td>R$ ${Number(product.price).toFixed(2)}</td>
          <td>${product.quantity}</td>
        </tr>
      `;

      return acc + li;
    }, "");

    tbody.innerHTML = htmlList;

    // setTimeout(init, 1000);
  });
};

init();
