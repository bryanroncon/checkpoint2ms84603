const [form] = document.forms;

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const data = new URLSearchParams(formData).toString();

  fetch("http://localhost:3000/produto", {
    method: "post",
    body: data,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  })
    .then(() => {
      e.target.reset();
      console.log("Produto inserido!");
    })
    .catch((error) => {
      console.log(error);
    });
});
