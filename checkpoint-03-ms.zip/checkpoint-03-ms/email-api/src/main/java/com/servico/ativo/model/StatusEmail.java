package com.servico.ativo.model;

public enum StatusEmail {
    SEND,
    ERROR
}
